# Pine Script v6 – Repositório DFX

Este repositório contém exemplos práticos, bibliotecas, estratégias e recursos de aprendizado voltados para desenvolvimento profissional de indicadores e estratégias automatizadas usando Pine Script v6 no TradingView.

## Conteúdo
- Exemplos comentados
- Estratégias avançadas
- Biblioteca SMC
- Webhook estruturado
- Boas práticas e links úteis

